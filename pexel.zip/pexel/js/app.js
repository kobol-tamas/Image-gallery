document.getElementById('getPhotos').addEventListener('click', getPhotos);

function getPhotos() {
    let searchValue = document.getElementById('input').value;
    let numberOfPictures = document.getElementById('number').value;
    const APIKey = '563492ad6f917000010000015c0c03409de5434d88c71099b28bad62';

    if (numberOfPictures === 0 || numberOfPictures === undefined) {
        const baseURL = `https://api.pexels.com/v1/search?query=${searchValue}&per_page=15`;
        fetch(baseURL, {
            headers: {
                Authorization: APIKey
            }
        })
            .then(res => res.json())
            .then(data => {
                const pics = data.photos;
                console.log(pics)

                let output = '';

                pics.forEach(pic => {
                    output += `
                <div class="gallery">
                <a href="${pic.src.large}" data-lightbox="mygallery"><img src="${pic.src.medium}"></a>
                </div>
                `
                });
                document.getElementById('output').innerHTML = output;
            });

    } else {
        const baseURL = `https://api.pexels.com/v1/search?query=${searchValue}&per_page=${numberOfPictures}`;
        fetch(baseURL, {
            headers: {
                Authorization: APIKey
            }
        })
            .then(res => res.json())
            .then(data => {
                const pics = data.photos;
                console.log(pics)

                let output = '';

                pics.forEach(pic => {
                    output += `
                <div class="gallery">
                <a href="${pic.src.large}" data-lightbox="mygallery"><img src="${pic.src.medium}"></a>
                </div>
                `
                });
                document.getElementById('output').innerHTML = output;
            });
    }
}